module.exports =[
    "./gulp/tasks/pug",
    "./gulp/tasks/serve",
    "./gulp/tasks/font",
    "./gulp/tasks/stylus",
    "./gulp/tasks/watch",
    "./gulp/tasks/scripts",
    "./gulp/tasks/img",
    "./gulp/tasks/video",
    "./gulp/tasks/svg",
]