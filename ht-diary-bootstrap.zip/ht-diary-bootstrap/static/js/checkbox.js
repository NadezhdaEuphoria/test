$(document).ready(function () {
    $('.toast').toast('show');
 });


